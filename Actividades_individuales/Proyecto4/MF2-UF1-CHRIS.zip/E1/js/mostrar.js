function mostrar() {
    document.getElementById("form2").style.visibility = "visible"; 
}

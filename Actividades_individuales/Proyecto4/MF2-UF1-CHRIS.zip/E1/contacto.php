<?php
include("includes/encabezado.php");
include("includes/menu.php");
?>

<?php
include("includes/pie.php");
?>
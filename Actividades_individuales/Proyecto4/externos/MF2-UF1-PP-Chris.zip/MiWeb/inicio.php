<?php
session_start();
   include("includes/encabezado.php");
   include("includes/menuBase.php");
   // encabezados y menu aqui se usa el menu base que es el que tiene el inicio el registro el login pero no los servicios
?>
<!-- Aquí empieza el cuerpo de la página -->
<center>
   <img src="img/camarero-sonriente-hermoso-que-sostiene-bandeja-champan_13339-34350.jpg" alt="Camarero sonriente sosteniendo una bandeja">
</center>
<center>
   <!-- esto son comentarios que uso para dejar claro que hago y se muestran en la pagina-->
<span style="color: red;"> <strong>Los comentarios en rojo explican el funcionamiento de la pagina, desde aqui puedes volver a darle clic a inicio o registrarte o iniciar sesion</strong></span>
</center>
<?php
include("includes/pie.php");
?>

</main>
<footer class="my-5 pt-5 text-muted text-center text-small">
        <p class="mb-1">&copy; 2022–2025 Prueba Practica</p>
        <ul class="list-inline">
          <li class="list-inline-item"><a href="#">Privacidad</a></li>
          <li class="list-inline-item"><a href="#">Terminos del servicio</a></li>
          <li class="list-inline-item"><a href="#">Soporte Técnico</a></li>
        </ul>
</footer>
</body>
</html>
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/Carrousel/boho-macrame-assortment-indoors.jpg" class="d-block w-100" alt="mesa con manualidades hechas en macramé">
    </div>
    <div class="carousel-item">
      <img src="img/Carrousel/close-up-hands-knitting-with-knitters.jpg" class="d-block w-100" alt="mujet tejiendo a dos agujas">
    </div>
    <div class="carousel-item">
      <img src="img/Carrousel/primer-plano-mujer-pintar-pina_23-2148264362.jpg" class="d-block w-100" alt="mujer pintando">
    </div>
    <div class="carousel-item">
      <img src="img/Carrousel/trabajo-artesanal-profesional-taller_23-2148801620.jpg" class="d-block w-100" alt="Manos trabajando con arcilla">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Anterior</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Siguiente</span>
  </button>
</div> 
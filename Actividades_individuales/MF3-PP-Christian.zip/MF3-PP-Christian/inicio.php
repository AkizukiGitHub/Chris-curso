<?php
    include("includes/encabezado.php");
    include("includes/menu.php");
    include("includes/carrousel.php");
?>
<body>
    
<!-- en el incio no hay mucho que comentar estan los includes que incluyen los menus para cuando no estas loggeado -->

</body>

<?php
    include("includes/pie.php");
?>
